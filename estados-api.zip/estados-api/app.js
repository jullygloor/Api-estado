const express = require('express');
const mysql = require('mysql2');

const app = express();
const port = 3000;

// Configuração do banco de dados sem senha
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    // senha omitida para conexão sem senha
    database: 'estados_db'
});

// Conectar ao banco de dados
db.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL.');
});

// Rota para retornar todos os estados
app.get('/', (req, res) => {
    db.query('SELECT * FROM estados', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// Rota para retornar um estado específico pelo ID
app.get('/estados/:id', (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM estados WHERE id = ?', [id], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Estado não encontrado' });
        }
        res.json(results);
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`API rodando em http://localhost:${port}`);
});